import React from 'react'
import Flight from './Flight/Flight'

const flights = (props) =>{
  return(
     
  <div >
     <Flight {...props}/>
  </div> 
      
    
  
)
  }  

export default flights;