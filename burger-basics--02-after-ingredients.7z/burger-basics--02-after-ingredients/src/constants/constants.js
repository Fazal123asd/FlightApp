export const admin = ["mohammedfazal94@gmail.com"];
export const staff = ['testfight27@gmail.com'];

// mohammedfazal@gmail.com
//asdf@qwe.com